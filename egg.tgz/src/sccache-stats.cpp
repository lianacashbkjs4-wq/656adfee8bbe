// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("sccache stats"); }
int main(){
  announce();
  return lionss_run_workload("sccache-stats");
}
