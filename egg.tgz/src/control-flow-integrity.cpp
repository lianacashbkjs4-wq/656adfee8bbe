// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("control flow integrity"); }
int main(){
  announce();
  return lionss_run_workload("control-flow-integrity");
}
