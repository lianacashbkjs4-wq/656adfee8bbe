// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("callgrind profile"); }
int main(){
  announce();
  return lionss_run_workload("callgrind-profile");
}
