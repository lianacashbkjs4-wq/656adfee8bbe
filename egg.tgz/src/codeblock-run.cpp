// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("codeblock run\n", stdout);
  return lionss_run_workload("codeblock-run");
}
