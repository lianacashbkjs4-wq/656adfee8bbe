// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("sandbox build\n", stdout);
  return lionss_run_workload("sandbox-build");
}
