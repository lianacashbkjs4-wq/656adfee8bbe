// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("llvm cov"); }
int main(){
  announce();
  return lionss_run_workload("llvm-cov");
}
