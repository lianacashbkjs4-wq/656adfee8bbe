// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("bazel build\n", stdout);
  return lionss_run_workload("bazel-build");
}
